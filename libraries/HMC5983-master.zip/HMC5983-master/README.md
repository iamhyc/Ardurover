HMC5983
=======

Proof of concept of an Arduino library for Honeywell's HMC5983 magnetic sensor.
